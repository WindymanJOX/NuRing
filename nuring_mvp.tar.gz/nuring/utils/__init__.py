"""Small utility helpers."""
